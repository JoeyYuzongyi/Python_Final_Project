#!/usr/bin/env python
# coding: utf-8

# ## 项目背景概述
# 青少年怀孕对母亲和儿童都是高风险，它们更有可能导致早产，低出生体重，分娩病危症和死亡。许多青春期怀孕是意料之外的，但年轻女孩可能会继续怀孕，放弃接受教育和就业的机会，或寻求不安全的堕胎方法。生殖健康是与生殖系统及其功能和过程有关的身心健康状态，可以通过怀孕和分娩期间的教育和服务，安全有效的避孕措施以及性传播疾病的预防和治疗来提供支持，低收入和中等收入国家中，怀孕和分娩的病发症是导致育龄妇女和致残的主要原因。
# 
# ## 全球青少年怀孕现状：
# 对一些青少年而言，怀孕和分娩是有计划、受期待的结果，但对许多人不是这样。青少年怀孕更常见于贫穷、没有受过教育的农村社区。在一些国家，未婚怀孕并不鲜见。相比之下，一些少女可能面临结婚的社会压力，而且一旦结婚，就有必须生产的压力。低收入和中等收入国家有30%以上的少女在18岁以前结婚，约有14%结婚时未满15岁。一些少女不知道如何避孕，性教育在许多国家都很缺乏。她们可能感到太难以或羞于寻求避孕服务；避孕药可能过于昂贵或者没有广泛或以合法渠道提供。即便在避孕药广泛提供的情况下，性活跃的青春期少女使用它们的几率也比成年人低。少女可能无法拒绝非自愿的性行为或抵制强迫的性行为，这些通常都是无保护的性行为。针对全球青少年怀孕的社会现状，该项目主要利用了全球青少年怀孕率，孕妇死亡率，各国人均GDP的数据来分析这三项指标的关系，并引申出青少年怀孕率所映射出的社会问题。[青少年怀孕世界卫生组织研究报告](https://www.who.int/maternal_child_adolescent/topics/maternal/adolescent_pregnancy/zh/)
# 
# ## 数据来源与参考文献
# [青少年怀孕率数据](http://datatopics.worldbank.org/world-development-indicators/themes/people.html#adolescent-fertility)
# 
# [青少年怀孕世界卫生组织研究报告](https://www.who.int/maternal_child_adolescent/topics/maternal/adolescent_pregnancy/zh/)

# In[56]:


import numpy as np
import pandas as pd
import csv, os

# In[57]:


from pyecharts.charts import Bar, Tab, Line, Map, Timeline, Grid, Scatter
from pyecharts import options as opts
import pandas as pd

# In[59]:


dfa = pd.read_csv('Adolescent_fertility_rate.csv', encoding='utf8')

# In[60]:


dfa

# In[61]:


dfa1 = dfa.dropna(axis=0, how='any')
dfa1

# In[63]:


x轴 = [int(x) for x in dfa1.columns.values[-8:]]
x轴

# In[64]:


dfa2 = print(list(dfa1.CountryName))
dfa2

# In[65]:


青少年怀孕率 = list(zip(list(dfa1.CountryName)))
print(青少年怀孕率)
print(type(青少年怀孕率))

# In[67]:


from pyecharts.faker import Faker

from pyecharts.charts import Map
from pyecharts import options as opts
from pyecharts.globals import ChartType, SymbolType


def timeline_map() -> Timeline:
    tl = Timeline()
    for i in range(2010, 2017):
        map0 = (
            Map()
                .add(
                "青少年怀孕率", (list(zip(list(dfa1.CountryName), list(dfa1["{}".format(i)])))), "world",
                is_map_symbol_show=False
            )
                .set_global_opts(
                title_opts=opts.TitleOpts(title="".format(i), subtitle="",
                                          subtitle_textstyle_opts=opts.TextStyleOpts(color="red", font_size=16,
                                                                                     font_style="italic")),
                visualmap_opts=opts.VisualMapOpts(min_=0, max_=100, series_index=0),

            )
        )
        tl.add(map0, "{}".format(i))
    return tl


timeline_map().render_notebook()

# ## 全球青少年怀孕率分析：
# - 以上轮播数据图表所显示的是2010年到2016年全球青少年怀孕率的数据分布图，从轮播地图上我们可以看到非洲国家的青少年怀孕率普遍较高，而欧洲和北美洲的青少年怀孕率较低；从时间的宏观角度去分析，虽然非洲地区的青少年怀孕率相比起其他国家要高出很多，但是从国家的数据上看，他们从2010年到2016年青少年怀孕率都是在逐年减少的趋势，当然从全球的数据来看，全球的青少年怀孕率也是呈现一个下降的趋势。

# In[72]:


dfb = pd.read_csv('GDP.csv', encoding='utf8')

# In[73]:


dfb

# In[74]:


dfb1 = dfb.dropna(axis=0, how='any')
dfb1

# In[75]:


x轴 = [int(x) for x in dfb1.columns.values[-8:]]
x轴

# In[76]:


dfb2 = print(list(dfb1.CountryName))
dfb2

# In[77]:


全球人均GDP = list(zip(list(dfb1.CountryName)))
print(全球人均GDP)
print(type(全球人均GDP))

# In[78]:


from pyecharts.faker import Faker

from pyecharts.charts import Map
from pyecharts import options as opts
from pyecharts.globals import ChartType, SymbolType


def timeline_map() -> Timeline:
    tl = Timeline()
    for i in range(2010, 2017):
        map0 = (
            Map()
                .add(
                "全球人均GDP", (list(zip(list(dfb1.CountryName), list(dfa1["{}".format(i)])))), "world",
                is_map_symbol_show=False
            )
                .set_global_opts(
                title_opts=opts.TitleOpts(title="".format(i), subtitle="",
                                          subtitle_textstyle_opts=opts.TextStyleOpts(color="red", font_size=16,
                                                                                     font_style="italic")),
                visualmap_opts=opts.VisualMapOpts(min_=0, max_=100, series_index=0),

            )
        )
        tl.add(map0, "{}".format(i))
    return tl


timeline_map().render_notebook()

# ## 全球人均GDP分析（结合全球青少年怀孕率现状）：
# - 以上数据图表显示的是2010年到2016年人均GDP的全球分布轮播图，从地图上的数据我们可以看出全球人均GDP的还是存在较大的差距的，从各大洲的角度来看的话，北美洲和欧洲的人均GDP较高，而非洲各国的人均GDP也是存在较大的差距的，许多南非地区的人均GDP较高，而西非地区的人均GDP较低，然后我还发现了一个很神奇的数据就是Angola的数据，全球人均GDP基本都是呈上升的趋势，的但是Angola的人均GDP却每年都在下降，这是一件很神奇的事情，据我所了解Angola是全球最不发达的国家之一，但是随着经济全球化的影响，Angola的人均GDP竟每年都在下降，但我们很庆幸的是从上一张图表中我们可以看出Angola的青少年怀孕率还是在逐年减少的，我们现在来结合上一张有关全球青少年怀孕率的轮播图来看，我们可以看出全球人均GDP和全球青少年怀孕率大部分是呈负相关的关系，人均GDP高的国家，青少年怀孕率就较低，而相反人均GDP较低的国家，青少年怀孕率就较高。接下来我将抽取8个青少年怀孕率较高的8个国家进行相应的数据分析。

# In[11]:


import pandas as pd

df = pd.read_csv("GDPandAFP_max.csv", encoding='GBK')
df

# In[12]:


print(list(df.country))

# In[13]:


print(list(df.GDP))

# In[14]:


print(list(df.Adolescent_fertility_rate))

# In[15]:


八国对比双指标数据 = list(zip(list(df.GDP), list(df.Adolescent_fertility_rate)))
print(八国对比双指标数据)

# In[16]:


八国对比双指标数据 = zip(list(df.GDP), list(df.Adolescent_fertility_rate))
print(八国对比双指标数据)

# In[17]:


from pyecharts import options as opts
from pyecharts.charts import Bar, Grid, Line, Scatter


def grid_vertical() -> Grid:
    bar = (
        Bar()
            .add_xaxis(list(df.country))
            .add_yaxis("青少年怀孕率最高八国GDP", list(df.GDP))
            .set_global_opts(title_opts=opts.TitleOpts(title="青少年怀孕率最高八国GDP"))
    )
    line = (
        Line()
            .add_xaxis(list(df.country))
            .add_yaxis("青少年怀孕率最高八国青少年怀孕率", list(df.Adolescent_fertility_rate))
            .set_global_opts(
            title_opts=opts.TitleOpts(title="青少年怀孕率最高八国青少年怀孕率", pos_top="48%"),
            legend_opts=opts.LegendOpts(pos_top="48%"),
        )
    )

    grid = (
        Grid()
            .add(bar, grid_opts=opts.GridOpts(pos_bottom="60%"))
            .add(line, grid_opts=opts.GridOpts(pos_top="60%"))
    )
    return grid


grid_vertical().render_notebook()

# ## 青少年怀孕率最高的8个国家数据对比图分析与反思：
# - 我抽取了这8个国家的2016年的人均GDP和青少年怀孕率的数据进行了分析比较，这八个国家分别是Angola，Mali, Chad, Niger, Burkina Faso, Central African Republic和Equatorial Guinea，这些国家普遍分布在非洲地区，这些国家的人均GDP相对较低，在世界分区中属于落后国家的行列，而这些国家政府在教育上又投资的多少，在教育方面是否存在一定的缺失，女性在社会上的地位又是处于一个怎样的地位，联合国人口基金会拉美及加勒比区域主任Esteban Caballero认为，少女高怀孕率与信息的缺乏、未能获得全面的性教育及生殖健康服务直接相关，“许多怀孕并非是故意的选择，而是一种结果。减少少女怀孕现象意味着必须掌握有效的避孕方法。”过早的怀孕对少女来说还不只是健康的问题，即使她们顺利生下了孩子，也要面对社会的各种压力。联合国儿童基金会区域主任Marita Perceval指出，许多女孩因为怀孕必须辍学，这对她们完成学业、就业以及参与公共政治生活的能力具有长期影响。“少女母亲更容易受到伤害，贫困和社会的排斥会一再被重复。”此外，许多数据报告还发现，在大多数国家，没有受过教育或只受过小学教育的少女，她们怀孕的可能性比受过中学或高等教育的女孩高4倍；与此同时，在一个国家中，与收入最高的五分之一家庭相比，收入最低的五分之一家庭的女孩成为少女母亲的可能性也要高3至4倍。土著女孩，特别是农村地区的土著女孩，更有可能在很小的年纪就怀孕。接下来我抽取了两个国家在教育投资上的数据分析，这两个国家分别是青少年怀孕率较高的一个国家Mali，一个是青少年怀孕率较低的国家Finland。

# In[1]:


import pandas as pd

df = pd.read_csv("min_AFR.csv", encoding='GBK', index_col='CountryName')
df

# In[2]:


x轴 = [int(x) for x in df.columns.values[-4:]]
x轴

# In[3]:


Netherlands = list(df.loc['Netherlands'].values)[-4:]
Netherlands

# In[4]:


Finland = list(df.loc['Finland'].values)[-4:]
Finland

# In[5]:


Korea = list(df.loc['Korea'].values)[-4:]
Korea

# In[6]:


Luxembourg = list(df.loc['Luxembourg'].values)[-4:]
Luxembourg

# In[7]:


import pandas as pd

dfe = pd.read_csv("education.csv", index_col=0)
dfe.head()

# In[8]:


dfe.columns = [int(x) for x in dfe.columns]
dfe.index = ['Finland', 'Mali']
dfe.head()

# In[9]:


dfe.loc["Finland", :]

# In[10]:


# 增加标题title，利用Layout做排版
# plotly.offline.init_notebook_mode()
import plotly as py
import plotly.graph_objs as go

Finland = go.Scatter(
    x=[pd.to_datetime('01/01/{y}'.format(y=x), format="%m/%d/%Y") for x in dfe.columns.values],
    y=dfe.loc["Finland", :].values,
    name="Finland"
)

Mali = go.Scatter(
    x=[pd.to_datetime('01/01/{y}'.format(y=x), format="%m/%d/%Y") for x in dfe.columns.values],
    y=dfe.loc["Mali", :].values,
    name="Mali"
)

layout = dict(xaxis=dict(rangeselector=dict(buttons=list([
    dict(count=1,
         label="1年",
         step="year",
         stepmode="backward"),
    dict(count=2,
         label="2年",
         step="year",
         stepmode="backward"),
    dict(count=3,
         label="3年",
         step="year",
         stepmode="backward"),
    dict(count=4,
         label="4年",
         step="year",
         stepmode="backward"),
    dict(step="all")
])),
    rangeslider=dict(bgcolor="#70EC57"),
    title='年份'
),
    yaxis=dict(title='两国教育程度对比图'),
    title="两国教育程度对比图"
)

fig = dict(data=[Finland, Mali], layout=layout)

py.offline.iplot(fig, filename="输出中文_含时间序列的滑块选择器.html")
#              ^^^这里可以只放数据data，也可以将数据data和排版layout结合，这是典型的面向对象


# ## Finland和Mali教育投入资金分析图：
# - 上图是关于Finland和Mal从1990年到2015年的政府教育投入资金的趋势图，可以看出从1990年开始Finland政府在教育方面的资金投入就比Mali要高出一倍，但是从趋势上看，Mali政府在教育投入上呈上升的趋势，到了2018年已经趋近0.9，而Finland政府在教育资源的投入中一直处于1.1左右的，并没有太大的变动，根据青少年怀孕率的数据图显示Mali的青少年怀孕率也是呈逐年下降的趋势。

# In[242]:


import pandas as pd
import csv, os
from pyecharts import options as opts
from pyecharts.globals import ChartType, SymbolType
from pyecharts.charts import Bar, Tab, Line, Map, Timeline, Grid, Scatter, Liquid

# In[243]:


import pandas as pd

df = pd.read_csv("max_AFR.csv", encoding='GBK', index_col='CountryName')
df

# In[244]:


x轴 = [int(x) for x in df.columns.values[-4:]]
x轴

# In[245]:


Angola = list(df.loc['Angola'].values)[-4:]
Angola

# In[246]:


Mali = list(df.loc['Mali'].values)[-4:]
Mali

# In[247]:


Chad = list(df.loc['Chad'].values)[-4:]
Chad

# In[248]:


Niger = list(df.loc['Niger'].values)[-4:]
Niger

# In[249]:


BurkinaFaso = list(df.loc['BurkinaFaso'].values)[-4:]
BurkinaFaso

# In[250]:


CentralAfricaRepublic = list(df.loc['CentralAfricaRepublic'].values)[-4:]
CentralAfricaRepublic

# In[251]:


EquatorialGuinea = list(df.loc['EquatorialGuinea'].values)[-4:]
EquatorialGuinea

# In[252]:


Zambia = list(df.loc['Zambia'].values)[-4:]
Zambia

# In[ ]:


# In[253]:


import pandas as pd
import csv, os
from pyecharts import options as opts
from pyecharts.globals import ChartType, SymbolType
from pyecharts.charts import Bar, Tab, Line, Map, Timeline, Grid, Scatter, Liquid


# In[254]:


def timeline_map() -> Timeline:
    tl = Timeline()
    for i in range(2010, 2017):
        map0 = (
            Map()
                .add(
                "青少年怀孕率", (list(zip(list(dfa1.CountryName), list(dfa1["{}".format(i)])))), "world",
                is_map_symbol_show=False
            )
                .set_global_opts(
                title_opts=opts.TitleOpts(title="".format(i), subtitle="",
                                          subtitle_textstyle_opts=opts.TextStyleOpts(color="red", font_size=16,
                                                                                     font_style="italic")),
                visualmap_opts=opts.VisualMapOpts(min_=0, max_=100, series_index=0),

            )
        )
        tl.add(map0, "{}".format(i))
    return tl


def overlap_line_scatter() -> Bar:
    x = list(['2014', '2015', '2016', '2017'])
    bar = (
        Bar()
            .add_xaxis(x)
            .add_yaxis("Netherlands", Netherlands)
            .add_yaxis("Finland", Finland)
            .add_yaxis("Korea", Korea)
            .add_yaxis("Luxembourg", Luxembourg)
            .set_global_opts(title_opts=opts.TitleOpts(title="青少年怀孕率最低四国数据"))
    )
    line = (
        Line()
            .add_xaxis(x)
            .add_yaxis("Netherlands", Netherlands)
            .add_yaxis("Finland", Finland)
            .add_yaxis("Korea", Korea)
            .add_yaxis("Luxembourg", Luxembourg)
    )
    bar.overlap(line)
    return bar


def data() -> Bar:
    x = list(['2014', '2015', '2016', '2017'])
    bar = (
        Bar()
            .add_xaxis(x)
            .add_yaxis("Angola", Angola)
            .add_yaxis("Mali", Mali)
            .add_yaxis("Chad", Chad)
            .add_yaxis("Niger", Niger)
            .add_yaxis("BurkinaFaso", BurkinaFaso)
            .add_yaxis("CentralAfricaRepublic", CentralAfricaRepublic)
            .add_yaxis("EquatorialGuinea", EquatorialGuinea)
            .add_yaxis("Zambia", Zambia)

            .set_global_opts(title_opts=opts.TitleOpts(title="Top8"))
    )

    return bar


tab = Tab()
tab.add(timeline_map(), "2010~2017青少年怀孕率地图")
tab.add(data(), "2014~2017青少年怀孕率最高八个国家数据")
tab.add(overlap_line_scatter(), "最低四国数据图")

tab.render_notebook()

# ### 以上三幅可视化数据图分别是2010年到2017年青少年怀孕率地图，2014年到2017年青少年怀孕率最高的8个国家数据柱状图和2014年到2017年青少年怀孕率最低的4个国家数据柱状图，把这三个图放在一起想让大家知道，每年约有1600万15-19岁的青少年生产，约占全世界所有生产的11%。这些生产中有95%发生在低收入和中等收入国家。中等收入国家青少年的平均生产率是高收入国家的一倍以上，低收入国家的这一比率要高出四倍。在青少年时期发生的生产比例在中国约为2%，拉丁美洲和加勒比为18%，撒哈拉以南非洲要超过50%。在低收入和中等收入国家，约有10%的女童到16岁时就成为母亲，这一比率在撒哈拉以南非洲和中南亚和东南亚地区最高。在15岁之前就开始妊娠的妇女比率在地区之间的差异很大，婚外育儿在许多国家都很常见。与亚洲国家相比，拉丁美洲、加勒比、部分撒哈拉以南非洲和高收入国家的婚外青少年怀孕比率更高。未婚青少年母亲生产更多情况下属于意外，更容易以引产而告终。在15岁之前首次出现性行为的女童中，有10%的人报告曾发生强迫性行为，这就会导致青少年意外妊娠。虽然10–19岁少女占全世界所有生产数的11%，但她们却占到因妊娠和生产而造成的疾病总负担（残疾调整生命年）的23%。在低收入和中等收入国家的所有不安全流产中，有14%属于年龄在15–19岁之间的妇女。每年约有250万名青少年实施不安全流产，与年长妇女相比，女青少年受到并发症的影响更加严重。在拉丁美洲，年龄在16岁以下的女青少年中发生的孕产妇死亡危险比20多岁妇女要高出四倍。所以我们呼吁各国必须要重视青少年怀孕率。

# In[ ]:
